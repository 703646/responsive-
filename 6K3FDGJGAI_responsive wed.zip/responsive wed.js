let plusSignEL = document.getElementById("plusSign");
let paragraphEL = document.getElementById("paragraph");
let minusSignEl = document.getElementById("minusSign");
plusSignEL.onclick = function() {
    paragraphEL.classList.toggle("d-none")

    plusSignEL.classList.add("d-none")
    minusSignEl.classList.toggle("d-none")
}
minusSignEl.onclick = function() {
    paragraphEL.classList.toggle("d-none")
    plusSignEL.classList.remove("d-none")
    minusSignEl.classList.toggle("d-none")
}